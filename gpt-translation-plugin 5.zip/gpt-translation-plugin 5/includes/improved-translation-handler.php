<?php
// improved-translation-handler.php

if (!defined('ABSPATH')) {
    exit;
}

function get_best_translation($text, $target_language, $page_id = null) {
    $base_language = get_option('gpt_translation_plugin_base_language', 'EN');
    
    // Si el idioma objetivo es el mismo que el base, no es necesario traducir
    if ($target_language === $base_language) {
        return $text;
    }

    // Intentar obtener la traducci��n almacenada
    $stored_translation = gpt_get_translation_from_json($text, $target_language, $page_id);
    if ($stored_translation !== false) {
        return $stored_translation;
    }

    // Si no hay traducci��n almacenada, traducir desde el idioma base
    $translated_text = gpt_translation_plugin_translate_text($text, $target_language);
    if ($translated_text && $translated_text !== $text) {
        gpt_translation_save_json($target_language, [$text => $translated_text], $page_id);
    }

    return $translated_text ?: $text;
}

function translate_page_content($page_id, $content, $target_language) {
    $dom = new DOMDocument();
    @$dom->loadHTML(mb_convert_encoding($content, 'HTML-ENTITIES', 'UTF-8'), LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);

    $xpath = new DOMXPath($dom);
    $textNodes = $xpath->query('//text()');

    foreach ($textNodes as $node) {
        $text = trim($node->nodeValue);
        if (!empty($text)) {
            $translated_text = get_best_translation($text, $target_language, $page_id);
            $node->nodeValue = $translated_text;
        }
    }

    return $dom->saveHTML();
}

function gpt_improved_translation_ajax_handler() {
    if (!isset($_POST['page_id'], $_POST['language'], $_POST['texts'], $_POST['previous_language'])) {
        wp_send_json_error('Missing parameters.');
        return;
    }

    $page_id = intval($_POST['page_id']);
    $target_language = sanitize_text_field($_POST['language']);
    $previous_language = sanitize_text_field($_POST['previous_language']);
    $texts = json_decode(stripslashes($_POST['texts']), true);
    $base_language = get_option('gpt_translation_plugin_base_language', 'EN');

    if (empty($texts) || empty($target_language)) {
        wp_send_json_error('Invalid text data or missing language.');
        return;
    }

    $translations = [];
    foreach ($texts as $text) {
        if ($target_language === $base_language) {
            // Si el idioma objetivo es el base, usar el texto original
            $translations[] = $text;
        } elseif ($previous_language !== $base_language) {
            // Si se est�� cambiando de un idioma no base a otro, buscar la traducci��n desde el base
            $base_text = gpt_get_translation_from_json($text, $base_language, $page_id);
            if ($base_text === false) {
                $base_text = $text; // Si no se encuentra, usar el texto original
            }
            $translations[] = get_best_translation($base_text, $target_language, $page_id);
        } else {
            // Traducci��n normal desde el idioma base
            $translations[] = get_best_translation($text, $target_language, $page_id);
        }
    }

    wp_send_json_success($translations);
}

// Reemplazar el manejador AJAX existente con el nuevo
remove_action('wp_ajax_gpt_translate_text', 'gpt_translation_plugin_ajax_handler');
remove_action('wp_ajax_nopriv_gpt_translate_text', 'gpt_translation_plugin_ajax_handler');
add_action('wp_ajax_gpt_translate_text', 'gpt_improved_translation_ajax_handler');
add_action('wp_ajax_nopriv_gpt_translate_text', 'gpt_improved_translation_ajax_handler');

?>