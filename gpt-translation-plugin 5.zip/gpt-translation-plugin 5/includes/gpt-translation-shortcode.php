<?php

// Shortcode para mostrar el selector de idioma
add_shortcode('gpt_translation_selector', 'gpt_translation_plugin_selector_shortcode');

function gpt_translation_plugin_selector_shortcode($atts) {
    $atts = shortcode_atts(array(
        'background' => 'white',
        'text_color' => 'black',
        'border_color' => '#ccc',
        'padding' => '8px',
        'font_size' => '14px',
        'border_radius' => '4px',
    ), $atts);

    $base_language = get_option('gpt_translation_plugin_base_language');
    $selected_languages = get_option('gpt_translation_plugin_languages', []);
    $available_languages = gpt_translation_available_languages();

    if (empty($selected_languages)) {
        return 'No hay idiomas seleccionados para traducci��n.';
    }

    if (empty($base_language)) {
        return 'El idioma base no est�� configurado correctamente.';
    }

    ob_start();
    ?>
    <style>
        #gpt-translation-selector {
            width: auto;
            padding: <?php echo esc_attr($atts['padding']); ?>;
            font-size: <?php echo esc_attr($atts['font_size']); ?>;
            background-color: <?php echo esc_attr($atts['background']); ?>;
            color: <?php echo esc_attr($atts['text_color']); ?>;
            border: 1px solid <?php echo esc_attr($atts['border_color']); ?>;
            border-radius: <?php echo esc_attr($atts['border_radius']); ?>;
            cursor: pointer;
            margin: 0;
        }
    </style>
    <select id="gpt-translation-selector">
        <option value="<?php echo esc_attr($base_language); ?>">
            <?php echo esc_html($available_languages[$base_language]); ?>
        </option>
        <?php foreach ($selected_languages as $code): if ($code !== $base_language): ?>
            <option value="<?php echo esc_attr($code); ?>">
                <?php echo esc_html($available_languages[$code]); ?>
            </option>
        <?php endif; endforeach; ?>
    </select>
    <?php
    return ob_get_clean();
}