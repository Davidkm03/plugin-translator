<?php

// Manejador AJAX para traducir texto
add_action('wp_ajax_gpt_translate_text', 'gpt_translation_plugin_ajax_handler');
add_action('wp_ajax_nopriv_gpt_translate_text', 'gpt_translation_plugin_ajax_handler');

// Manejador AJAX para verificar traducciones almacenadas
add_action('wp_ajax_gpt_check_stored_translations', 'gpt_check_stored_translations');
add_action('wp_ajax_nopriv_gpt_check_stored_translations', 'gpt_check_stored_translations');

// Función para manejar la traducción de texto vía AJAX
function gpt_translation_plugin_ajax_handler() {
    if (!isset($_POST['language'], $_POST['texts'])) {
        wp_send_json_error('Faltan parámetros.');
        return;
    }

    $target_language = sanitize_text_field($_POST['language']);
    $texts = json_decode(stripslashes($_POST['texts']), true);

    if (empty($texts) || empty($target_language)) {
        wp_send_json_error('Datos de texto inválidos o falta de idioma.');
        return;
    }

    // Obtener el idioma base
    $base_language = get_option('gpt_translation_plugin_base_language', 'EN');
    $translations = [];

    // Procesar los textos para buscar la traducción adecuada
    foreach ($texts as $text) {
        // Intentar obtener la traducción desde el JSON del idioma objetivo
        $translated_text = gpt_get_translation_from_json($text, $target_language);

        if (!$translated_text) {
            // Si no se encuentra la traducción en el idioma objetivo, buscamos en el idioma base
            $base_translation = gpt_get_translation_from_json($text, $base_language);

            if ($base_translation) {
                // Si existe la traducción desde el idioma base, traduce desde el base al idioma objetivo
                $translated_text = gpt_translate_and_save_json($base_translation, $base_language, $target_language);
            } else {
                // Si no existe, traducir desde el idioma base y guardar en JSON
                $translated_text = gpt_translate_and_save_json($text, $base_language, $target_language);
            }

            // Si la traducción no tiene éxito, retornar un error
            if (!$translated_text) {
                error_log('Error al traducir el texto: ' . $text . ' Language: ' . $target_language);
                wp_send_json_error('Error al traducir los textos.');
                return;
            }
        }

        // Añadir la traducción final al array de resultados
        $translations[] = $translated_text;
    }

    // Retornar las traducciones si existen
    if (!empty($translations)) {
        wp_send_json_success($translations);
    } else {
        error_log('Error desconocido en la traducción.');
        wp_send_json_error('Error al traducir los textos.');
    }
}

// Función para verificar si las traducciones ya están almacenadas
function gpt_check_stored_translations() {
    if (!isset($_POST['language'], $_POST['texts'])) {
        wp_send_json_error('Faltan parámetros.');
        return;
    }

    $target_language = sanitize_text_field($_POST['language']);
    $texts = json_decode(stripslashes($_POST['texts']), true);

    if (empty($texts) || empty($target_language)) {
        wp_send_json_error('Datos de texto inválidos o falta de idioma.');
        return;
    }

    $translations = [];
    foreach ($texts as $text) {
        // Intentar obtener la traducción desde JSON
        $stored_translation = gpt_get_translation_from_json($text, $target_language);
        if ($stored_translation) {
            $translations[] = $stored_translation;
        } else {
            // Si alguna traducción no está almacenada, devolvemos un error
            wp_send_json_success([]); // No hay traducciones almacenadas
            return;
        }
    }

    // Si todas las traducciones están almacenadas, las retornamos
    wp_send_json_success($translations);
}

// Obtener la traducción desde JSON
if (!function_exists('gpt_get_translation_from_json')) {
    function gpt_get_translation_from_json($text, $language) {
        $translations_dir = gpt_create_translations_folder();
        $json_file = $translations_dir . 'translations-' . $language . '.json';

        // Verificar si el archivo JSON del idioma ya existe
        if (file_exists($json_file)) {
            $json_data = json_decode(file_get_contents($json_file), true);

            // Verificar si el texto ya está traducido
            if (isset($json_data[$text])) {
                return $json_data[$text];
            }
        }

        return false;
    }
}

// Traducir el texto y guardar en JSON
if (!function_exists('gpt_translate_and_save_json')) {
    function gpt_translate_and_save_json($text, $base_language, $target_language) {
        // Verificar si ya existe la traducción en el archivo JSON del idioma objetivo
        $stored_translation = gpt_get_translation_from_json($text, $target_language);
        
        if ($stored_translation) {
            return $stored_translation;  // Si ya existe, devolver la traducción almacenada
        }

        // Si no existe, obtener la traducción desde el idioma base
        $base_translation = gpt_get_translation_from_json($text, $base_language);
        
        if ($base_translation) {
            // Traducir desde el idioma base al idioma objetivo y guardar
            $translated_text = gpt_translation_plugin_translate_text($base_translation, $target_language);
            gpt_save_translation_to_json($text, $target_language, $translated_text);

            return $translated_text;
        }

        // Si no existe en el idioma base, solicitar la traducción directamente
        $translated_text = gpt_translation_plugin_translate_text($text, $target_language);
        gpt_save_translation_to_json($text, $target_language, $translated_text);

        return $translated_text;
    }
}

// Guardar la traducción en JSON
if (!function_exists('gpt_save_translation_to_json')) {
    function gpt_save_translation_to_json($text, $language, $translated_text) {
        $translations_dir = gpt_create_translations_folder();
        $json_file = $translations_dir . 'translations-' . $language . '.json';

        // Leer el archivo JSON si ya existe
        if (file_exists($json_file)) {
            $json_data = json_decode(file_get_contents($json_file), true);
        } else {
            $json_data = [];
        }

        // Agregar o actualizar la traducción
        $json_data[$text] = $translated_text;

        // Guardar el archivo JSON actualizado
        file_put_contents($json_file, json_encode($json_data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    }
}

// Crear el directorio de traducciones si no existe
if (!function_exists('gpt_create_translations_folder')) {
    function gpt_create_translations_folder() {
        $upload_dir = wp_upload_dir();
        $translations_dir = $upload_dir['basedir'] . '/translations/';

        if (!file_exists($translations_dir)) {
            wp_mkdir_p($translations_dir);
        }

        return $translations_dir;
    }
}

// Función para realizar la traducción utilizando la API de OpenAI
if (!function_exists('gpt_translation_plugin_translate_text')) {
    function gpt_translation_plugin_translate_text($text, $target_language) {
        $api_key = get_option('gpt_translation_plugin_api_key');
        $base_language = get_option('gpt_translation_plugin_base_language');

        if (!$api_key) {
            return 'La clave API no está configurada.';
        }

        if (empty($text)) {
            return 'El texto a traducir no puede estar vacío.';
        }

        if (empty($target_language)) {
            return 'El idioma de destino no está especificado.';
        }

        $response = translate_text_via_api($text, $base_language, $target_language, $api_key);
        return $response;  // Retornar el contenido completo traducido
    }
}

