<?php
/*
Plugin Name: GPT Translation Plugin
Description: A plugin to translate website content using the ChatGPT API.
Version: 2.2
Author: Juan David Valor Campos
*/

// Evitar acceso directo al archivo
if (!defined('ABSPATH')) {
    exit;
}

// Incluir archivos necesarios
include_once plugin_dir_path(__FILE__) . 'admin/gpt-translation-settings.php';
include_once plugin_dir_path(__FILE__) . 'includes/gpt-translation-functions.php';
include_once plugin_dir_path(__FILE__) . 'includes/gpt-translation-ajax.php';
include_once plugin_dir_path(__FILE__) . 'includes/gpt-translation-shortcode.php';
include_once plugin_dir_path(__FILE__) . 'includes/improved-translation-handler.php';



// Encolar scripts y estilos
add_action('admin_enqueue_scripts', 'gpt_translation_enqueue_admin_styles');
add_action('wp_enqueue_scripts', 'gpt_translation_enqueue_public_scripts');

// Encola estilos y scripts
function gpt_translation_enqueue_admin_styles() {
    wp_enqueue_style('gpt-translation-admin-style', plugin_dir_url(__FILE__) . 'admin/css/admin-style.css');
     wp_enqueue_script('jquery-ui-core');
    wp_enqueue_script('jquery-ui-tabs');
    wp_enqueue_style('jquery-ui-css', 'https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css');
}

function gpt_translation_plugin_register_settings() {
    register_setting('gpt_translation_plugin_options', 'gpt_translation_plugin_base_language');
    register_setting('gpt_translation_plugin_options', 'gpt_translation_plugin_languages');
}
add_action('admin_init', 'gpt_translation_plugin_register_settings');


function gpt_translation_enqueue_public_scripts() {
    wp_enqueue_script('gpt-translation-script', plugin_dir_url(__FILE__) . 'public/js/gpt-translation.js', ['jquery'], null, true);
    wp_localize_script('gpt-translation-script', 'gptTranslationAjax', [
        'ajaxurl' => admin_url('admin-ajax.php'),
        'baseLanguage' => get_option('gpt_translation_plugin_base_language', 'EN'),
        'currentPageId' => get_the_ID()
    ]);
}

// Función para crear el directorio de traducciones
function gpt_create_translations_folder() {
    $upload_dir = wp_upload_dir();
    $translations_dir = $upload_dir['basedir'] . '/translations/';
    
    if (!file_exists($translations_dir)) {
        wp_mkdir_p($translations_dir);
    }
    
    return $translations_dir;
}

// Guardar las traducciones en JSON
function gpt_translation_save_json($language, $translations, $page_id = null) {
    $translations_dir = gpt_create_translations_folder();
    $file_name = $page_id ? "translations-{$page_id}-{$language}.json" : "translations-{$language}.json";
    $json_file = $translations_dir . $file_name;
    
    // Leer el archivo JSON si ya existe
    if (file_exists($json_file)) {
        $json_data = json_decode(file_get_contents($json_file), true);
    } else {
        $json_data = [];
    }

    // Actualizar las traducciones sin sobreescribir las existentes
    foreach ($translations as $key => $value) {
        $json_data[$key] = $value; // Sobreescribimos solo las claves específicas
    }

    // Guardar el archivo JSON actualizado
    file_put_contents($json_file, json_encode($json_data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}

// Obtener la traducción desde JSON
function gpt_get_translation_from_json($text, $language, $page_id = null) {
    $translations_dir = gpt_create_translations_folder();
    $file_name = $page_id ? "translations-{$page_id}-{$language}.json" : "translations-{$language}.json";
    $json_file = $translations_dir . $file_name;

    // Verificar si el archivo JSON del idioma ya existe
    if (file_exists($json_file)) {
        $json_data = json_decode(file_get_contents($json_file), true);

        // Verificar si el texto ya está traducido
        if (isset($json_data[$text])) {
            return $json_data[$text];
        }
    }

    return false;
}

// Traducir el texto y guardar en JSON
function gpt_translate_and_save($texts, $target_language, $page_id = null) {
    $base_language = get_option('gpt_translation_plugin_base_language', 'EN');
    
    // Si el idioma objetivo es el mismo que el idioma base, no es necesario traducir
    if ($target_language === $base_language) {
        return $texts;
    }

    $translations = [];
    foreach ($texts as $text) {
        // Verificar si ya existe una traducción desde el idioma base
        $stored_translation = gpt_get_translation_from_json($text, $target_language, $page_id);
        if (!$stored_translation) {
            // Obtener la traducción del idioma base al idioma objetivo si no está guardada
            $translated_text = gpt_translation_plugin_translate_text($text, $target_language);
            
            if ($translated_text) {
                // Guardar la traducción en JSON
                gpt_translation_save_json($target_language, [$text => $translated_text], $page_id);
                $translations[] = $translated_text;
            }
        } else {
            // Usar la traducción almacenada
            $translations[] = $stored_translation;
        }
    }

    return $translations;
}

// Función para categorizar y traducir el contenido por partes
function gpt_translate_page($page_content, $language, $page_id) {
    $sections = gpt_categorize_content($page_content); // Divide en títulos, párrafos, botones, etc.
    
    foreach ($sections as $category => $texts) {
        gpt_translate_and_save($texts, $language, $page_id);
    }
}

// Función para categorizar el contenido en títulos, párrafos, botones y menús
function gpt_categorize_content($content) {
    $categories = [
        'paragraphs' => [],
        'titles' => [],
        'buttons' => [],
        'menus' => []
    ];

    // Extraer los títulos (h1, h2, h3, etc.)
    preg_match_all('/<h[1-6][^>]*>(.*?)<\/h[1-6]>/', $content, $title_matches);
    if (!empty($title_matches[1])) {
        $categories['titles'] = array_map('strip_tags', $title_matches[1]); // Limpiar las etiquetas HTML
    }

    // Extraer los párrafos
    preg_match_all('/<p[^>]*>(.*?)<\/p>/', $content, $paragraph_matches);
    if (!empty($paragraph_matches[1])) {
        $categories['paragraphs'] = array_map('strip_tags', $paragraph_matches[1]);
    }

    // Extraer los botones (enlaces o botones con la etiqueta <button> o <a> con clase de botón)
    preg_match_all('/<(button|a)[^>]*>(.*?)<\/(button|a)>/', $content, $button_matches);
    if (!empty($button_matches[2])) {
        $categories['buttons'] = array_map('strip_tags', $button_matches[2]);
    }

    // Extraer los menús (asumiendo que los menús se encuentran en listas <ul> o <nav>)
    preg_match_all('/<nav[^>]*>(.*?)<\/nav>|<ul[^>]*>(.*?)<\/ul>/', $content, $menu_matches);
    foreach ($menu_matches as $menu) {
        if (!empty($menu)) {
            $cleaned_menu = strip_tags($menu);
            if (!empty($cleaned_menu)) {
                $categories['menus'][] = $cleaned_menu;
            }
        }
    }

    return $categories;
}

// Función para traducir el texto usando la API
function gpt_translation_plugin_translate_text($text, $target_language) {
    $api_key = get_option('gpt_translation_plugin_api_key');
    $base_language = get_option('gpt_translation_plugin_base_language');

    if (!$api_key) {
        return 'La clave API no está configurada.';
    }

    if (empty($text)) {
        return 'El texto a traducir no puede estar vacío.';
    }

    if (empty($target_language)) {
        return 'El idioma de destino no está especificado.';
    }

    $response = translate_text_via_api($text, $base_language, $target_language, $api_key);
    return $response;  // Retornar el contenido completo traducido
}

// Función que envía la solicitud a la API de OpenAI
function translate_text_via_api($text, $base_language, $target_language, $api_key) {
    $url = 'https://api.openai.com/v1/chat/completions';
    $data = [
        'model' => 'gpt-4o-mini',
        'messages' => [
            ['role' => 'system', 'content' => "You are a professional website translator. Translate the following text from $base_language to $target_language. Focus on making the translation accurate and natural for a website context. Do not ask for more context. Just translate the text directly."],
            ['role' => 'user', 'content' => $text]
        ],
        'max_tokens' => 16000
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $api_key
    ]);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);  // Añadir un timeout de 30 segundos

    $result = curl_exec($ch);

    if ($result === false) {
        return 'Error al conectar con la API de OpenAI: ' . curl_error($ch);
    }

    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $response = json_decode($result, true);

    if ($httpcode !== 200) {
        return isset($response['error']) ? "Error de la API de OpenAI: " . $response['error']['message'] : 'Error desconocido de la API de OpenAI. Código HTTP: ' . $httpcode;
    }

    return isset($response['choices'][0]['message']['content']) ? $response['choices'][0]['message']['content'] : 'Respuesta inesperada de la API de OpenAI.';
}

// Filtro para traducir el contenido de la página
function gpt_translation_plugin_translate_content($content) {
    $current_language = isset($_COOKIE['gpt_translation_language']) ? $_COOKIE['gpt_translation_language'] : get_option('gpt_translation_plugin_base_language');
    $base_language = get_option('gpt_translation_plugin_base_language');

    if ($current_language !== $base_language) {
        $page_id = get_the_ID();
        $content = translate_page_content($page_id, $content, $current_language);
    }

    return $content;
}
add_filter('the_content', 'gpt_translation_plugin_translate_content');