<?php
// Añadir menú al panel de administración
add_action('admin_menu', 'gpt_translation_plugin_menu');

function gpt_translation_plugin_menu() {
    add_menu_page(
        'GPT Translation',
        'GPT Translation',
        'manage_options',
        'gpt-translation-plugin',
        'gpt_translation_plugin_settings_page',
        'dashicons-translation'
    );
    add_submenu_page(
        'gpt-translation-plugin',
        'Edit Translations',
        'Edit Translations',
        'manage_options',
        'gpt-translation-edit',
        'gpt_translation_edit_page'
    );
}

// Registro de opciones y configuración
function gpt_translation_register_settings() {
    // Registrar la opción principal del plugin
    register_setting(
        'gpt_translation_plugin_options',   // Grupo de opciones
        'gpt_translation_plugin_base_language'  // Nombre de la opción
    );
    register_setting(
        'gpt_translation_plugin_options',   // Grupo de opciones
        'gpt_translation_plugin_languages'  // Idiomas seleccionados
    );
    
    // Registrar la opción de estilo del widget
    register_setting(
        'gpt_translation_widget_styling',    // Grupo de opciones
        'gpt_translation_widget_styling',    // Nombre de la opción
        'gpt_translation_widget_styling_sanitize'  // Función de sanitización
    );

    // Añadir la sección de estilo del widget
    add_settings_section(
        'gpt_translation_widget_styling_section',
        'Configuración de Estilo del Widget',
        'gpt_translation_widget_styling_section_callback',
        'gpt_translation_plugin'
    );

    // Añadir los campos de configuración del widget
    add_settings_field(
        'background_color',
        'Color de fondo',
        'gpt_translation_widget_styling_color_callback',
        'gpt_translation_plugin',
        'gpt_translation_widget_styling_section',
        array('background_color')
    );
    add_settings_field(
        'text_color',
        'Color del texto',
        'gpt_translation_widget_styling_color_callback',
        'gpt_translation_plugin',
        'gpt_translation_widget_styling_section',
        array('text_color')
    );
    add_settings_field(
        'border_color',
        'Color del borde',
        'gpt_translation_widget_styling_color_callback',
        'gpt_translation_plugin',
        'gpt_translation_widget_styling_section',
        array('border_color')
    );
    add_settings_field(
        'hover_color',
        'Color al pasar el mouse',
        'gpt_translation_widget_styling_color_callback',
        'gpt_translation_plugin',
        'gpt_translation_widget_styling_section',
        array('hover_color')
    );
    add_settings_field(
        'font_name',
        'Nombre de la fuente',
        'gpt_translation_widget_styling_text_callback',
        'gpt_translation_plugin',
        'gpt_translation_widget_styling_section',
        array('font_name')
    );
    add_settings_field(
        'padding',
        'Padding (px)',
        'gpt_translation_widget_styling_number_callback',
        'gpt_translation_plugin',
        'gpt_translation_widget_styling_section',
        array('padding')
    );
    add_settings_field(
        'border_width',
        'Grosor del borde (px)',
        'gpt_translation_widget_styling_number_callback',
        'gpt_translation_plugin',
        'gpt_translation_widget_styling_section',
        array('border_width')
    );
}
add_action('admin_init', 'gpt_translation_register_settings');

// Página de configuración del plugin
function gpt_translation_plugin_settings_page() {
    $active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'general';
    ?>
    <div class="wrap">
        <h1>Configuración de GPT Translation Plugin</h1>
        
        <h2 class="nav-tab-wrapper">
            <a href="?page=gpt-translation-plugin&tab=general" class="nav-tab <?php echo $active_tab == 'general' ? 'nav-tab-active' : ''; ?>">General</a>
            <a href="?page=gpt-translation-plugin&tab=style" class="nav-tab <?php echo $active_tab == 'style' ? 'nav-tab-active' : ''; ?>">Estilo</a>
        </h2>
        
        <form method="post" action="options.php">
            <?php
            if ($active_tab == 'general') {
                settings_fields('gpt_translation_plugin_options');
                // Mostrar el campo para el idioma base
                $base_language = get_option('gpt_translation_plugin_base_language', 'EN');
                $available_languages = gpt_translation_available_languages();
                ?>
                <h3>Idioma Base</h3>
                <select name="gpt_translation_plugin_base_language">
                    <?php foreach ($available_languages as $code => $language_name): ?>
                        <option value="<?php echo esc_attr($code); ?>" <?php selected($base_language, $code); ?>>
                            <?php echo esc_html($language_name); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                
                <h3>Idiomas de Destino</h3>
                <?php
                $selected_languages = get_option('gpt_translation_plugin_languages', []);
                foreach ($available_languages as $code => $language_name) {
                    if ($code !== $base_language) {
                        $checked = in_array($code, $selected_languages) ? 'checked' : '';
                        echo "<label><input type='checkbox' name='gpt_translation_plugin_languages[]' value='" . esc_attr($code) . "' $checked> " . esc_html($language_name) . "</label><br>";
                    }
                }
                do_settings_sections('gpt_translation_plugin');
            } elseif ($active_tab == 'style') {
                gpt_translation_widget_styling_options();
            }
            submit_button();
            ?>
        </form>

        <?php if ($active_tab == 'general'): ?>
        <h2>Cómo usar el plugin</h2>
        <p>Para utilizar el selector de idioma en tu sitio, simplemente copia y pega el siguiente shortcode en cualquier página, publicación o widget:</p>
        <code>[gpt_translation_selector]</code>
        <p>Este shortcode generará un selector de idioma que tus visitantes podrán utilizar para traducir el contenido del sitio.</p>
        <p>Puedes personalizar el aspecto del selector utilizando atributos en el shortcode. Por ejemplo:</p>
        <code>[gpt_translation_selector background="blue" text_color="white" border_color="#000" padding="10px" font_size="16px" border_radius="8px"]</code>
        <?php endif; ?>
    </div>
    <?php
}

// Página para editar traducciones
function gpt_translation_edit_page() {
    $languages = get_option('gpt_translation_plugin_languages', []);
    $base_language = get_option('gpt_translation_plugin_base_language', 'EN');
    $pages = get_pages();
    ?>
    <div class="wrap">
        <h1>Edit Translations</h1>
        <select id="language-selector">
            <?php
            foreach ($languages as $code) {
                if ($code !== $base_language) {
                    echo "<option value='" . esc_attr($code) . "'>" . esc_html($code) . "</option>";
                }
            }
            ?>
        </select>
        
        <div id="page-tabs">
            <ul>
                <?php
                foreach ($pages as $page) {
                    echo "<li><a href='#page-" . $page->ID . "'>" . esc_html($page->post_title) . "</a></li>";
                }
                ?>
            </ul>
            
            <?php
            foreach ($pages as $page) {
                echo "<div id='page-" . $page->ID . "'>";
                echo "<h2>" . esc_html($page->post_title) . " Translations</h2>";
                echo "<div id='translations-container-" . $page->ID . "'></div>";
                echo "</div>";
            }
            ?>
        </div>
    </div>
    <script>
    jQuery(document).ready(function($) {
        $("#page-tabs").tabs();

        function loadTranslations(language, pageId) {
            $.ajax({
                url: ajaxurl,
                method: 'POST',
                data: {
                    action: 'gpt_load_translations',
                    language: language,
                    page_id: pageId
                },
                success: function(response) {
                    if (response.success) {
                        var html = '<table class="wp-list-table widefat fixed striped">';
                        html += '<thead><tr><th>Original</th><th>Translation</th><th>Actions</th></tr></thead><tbody>';
                        for (var key in response.data) {
                            html += '<tr>';
                            html += '<td>' + key + '</td>';
                            html += '<td><input type="text" class="translation-input" data-key="' + key + '" value="' + (response.data[key] || '') + '"></td>';
                            html += '<td><button class="button save-translation" data-key="' + key + '" data-page="' + pageId + '">Save</button></td>';
                            html += '</tr>';
                        }
                        html += '</tbody></table>';
                        $('#translations-container-' + pageId).html(html);
                    } else {
                        $('#translations-container-' + pageId).html('<p>No translations found for this page.</p>');
                    }
                }
            });
        }

        $('#language-selector').change(function() {
            var language = $(this).val();
            $('#page-tabs > div').each(function() {
                var pageId = $(this).attr('id').split('-')[1];
                loadTranslations(language, pageId);
            });
        });

        $(document).on('click', '.save-translation', function() {
            var key = $(this).data('key');
            var pageId = $(this).data('page');
            var value = $('input[data-key="' + key + '"]').val();
            var language = $('#language-selector').val();

            $.ajax({
                url: ajaxurl,
                method: 'POST',
                data: {
                    action: 'gpt_save_translation',
                    language: language,
                    page_id: pageId,
                    key: key,
                    value: value
                },
                success: function(response) {
                    if (response.success) {
                        alert('Translation saved successfully!');
                    } else {
                        alert('Error saving translation.');
                    }
                }
            });
        });

        // Load translations for the first language and all pages on page load
        var initialLanguage = $('#language-selector').val();
        $('#page-tabs > div').each(function() {
            var pageId = $(this).attr('id').split('-')[1];
            loadTranslations(initialLanguage, pageId);
        });
    });
    </script>
    <?php
}

// Funciones adicionales
function gpt_load_translations() {
    $language = sanitize_text_field($_POST['language']);
    $page_id = intval($_POST['page_id']);
    $translations = gpt_get_all_translations_from_json($language, $page_id);
    
    if (!empty($translations)) {
        wp_send_json_success($translations);
    } else {
        wp_send_json_error('No translations found');
    }
}

function gpt_get_all_translations_from_json($language, $page_id) {
    $translations_dir = gpt_create_translations_folder();
    $json_file = $translations_dir . 'translations-' . $page_id . '-' . $language . '.json';

    if (file_exists($json_file)) {
        $translations = json_decode(file_get_contents($json_file), true);
        if (json_last_error() === JSON_ERROR_NONE) {
            return $translations;
        }
    }

    return [];
}

// Nuevas funciones para el estilo del widget
function gpt_translation_widget_styling_options() {
    // Registrar las opciones de estilo si no existen
    if (false === get_option('gpt_translation_widget_styling')) {
        add_option('gpt_translation_widget_styling', array(
            'background_color' => '#ffffff',
            'text_color' => '#000000',
            'border_color' => '#cccccc',
            'hover_color' => '#f0f0f0',
            'font_name' => '',
            'padding' => 5,
            'border_width' => 1,
        ));
    }

    // Mostrar los campos de estilo
    settings_fields('gpt_translation_widget_styling');
    do_settings_sections('gpt_translation_plugin');
}

function gpt_translation_widget_styling_section_callback() {
    echo '<p>Personaliza el aspecto del selector de idiomas.</p>';
}

function gpt_translation_widget_styling_color_callback($args) {
    $options = get_option('gpt_translation_widget_styling');
    $field = $args[0];
    echo "<input type='color' name='gpt_translation_widget_styling[$field]' value='" . esc_attr($options[$field]) . "' />";
}

function gpt_translation_widget_styling_text_callback($args) {
    $options = get_option('gpt_translation_widget_styling');
    $field = $args[0];
    echo '<td><textarea class="translation-input" data-key="' + key + '">' + (response.data[key] || '') + '</textarea></td>';

}

function gpt_translation_widget_styling_number_callback($args) {
    $options = get_option('gpt_translation_widget_styling');
    $field = $args[0];
    echo "<input type='number' name='gpt_translation_widget_styling[$field]' value='" . esc_attr($options[$field]) . "' />";
}

function gpt_translation_widget_styling_sanitize($input) {
    $new_input = array();
    foreach ($input as $key => $value) {
        if (in_array($key, array('background_color', 'text_color', 'border_color', 'hover_color'))) {
            $new_input[$key] = sanitize_hex_color($value);
        } elseif ($key == 'font_name') {
            $new_input[$key] = sanitize_text_field($value);
        } elseif (in_array($key, array('padding', 'border_width'))) {
            $new_input[$key] = intval($value);
        }
    }
    return $new_input;
}

// Asegúrate de que esta función esté registrada para manejar la acción AJAX
add_action('wp_ajax_gpt_load_translations', 'gpt_load_translations');
