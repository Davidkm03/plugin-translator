document.addEventListener('DOMContentLoaded', function () {
    var baseLanguage = gptTranslationAjax.baseLanguage || 'EN';
    var storedLanguage = localStorage.getItem('gpt_translation_language') || baseLanguage;
    var currentPageId = gptTranslationAjax.currentPageId || '0';  // Obtener currentPageId de gptTranslationAjax
    var currentLanguage = storedLanguage;  // Añadido para rastrear el idioma actual

    // Establecer el valor del selector de idioma
    setSelectorValue(storedLanguage);

    // Si el idioma almacenado no es el idioma base, aplicamos las traducciones
    if (storedLanguage !== baseLanguage) {
        applyStoredTranslations(storedLanguage, baseLanguage);
    }

    // Evento para manejar el cambio de idioma desde el selector
    var selector = document.getElementById('gpt-translation-selector');
    if (selector) {
        selector.addEventListener('change', function () {
            var language = this.value;
            handleLanguageChange(language, baseLanguage);
        });
    }

    // Función para establecer el valor del selector de idioma
    function setSelectorValue(language) {
        var selector = document.getElementById('gpt-translation-selector');
        if (selector) {
            selector.value = language;
        }
    }

    // Función para manejar el cambio de idioma
    function handleLanguageChange(language, baseLanguage) {
        var previousLanguage = currentLanguage;  // Guardar el idioma anterior
        currentLanguage = language;  // Actualizar el idioma actual

        if (language === baseLanguage) {
            localStorage.removeItem('gpt_translation_language');
            location.reload();  // Recargar la página para regresar al idioma base
        } else {
            localStorage.setItem('gpt_translation_language', language);
            applyStoredTranslations(language, baseLanguage, previousLanguage);  // Pasar el idioma anterior
        }
    }

    // Función para aplicar las traducciones almacenadas en el archivo JSON
    function applyStoredTranslations(language, baseLanguage, previousLanguage) {
        var textsToTranslate = [];
        var nodeMapping = [];
        var selectors = ['h1', 'h2', 'p', 'button', 'nav', 'a', '.elementor-button-text'];  // Elementos a traducir

        // Recorremos los elementos para obtener los textos
        selectors.forEach(function (selector) {
            var elements = document.querySelectorAll(selector);
            elements.forEach(function (element) {
                element.childNodes.forEach(function (node) {
                    if (node.nodeType === Node.TEXT_NODE && node.nodeValue.trim() !== '') {
                        textsToTranslate.push(node.nodeValue.trim());
                        nodeMapping.push(node);
                    }
                });
            });
        });

        // Verificamos si las traducciones ya están almacenadas, usando siempre el idioma base como referencia
        checkStoredTranslations(textsToTranslate, nodeMapping, language, baseLanguage, previousLanguage);
    }

    // Función para verificar si las traducciones están almacenadas en el servidor
    function checkStoredTranslations(textsToTranslate, nodeMapping, language, baseLanguage, previousLanguage) {
        var xhr = new XMLHttpRequest();
        xhr.open('POST', gptTranslationAjax.ajaxurl, true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
        xhr.onload = function () {
            if (xhr.status >= 200 && xhr.status < 400) {
                var response = JSON.parse(xhr.responseText);
                if (response.success && response.data.length > 0) {
                    console.log('Traducciones encontradas. Aplicando traducciones...');
                    applyTranslations(response.data, nodeMapping);
                } else {
                    console.log('Traducciones no encontradas. Solicitando nuevas traducciones...');
                    sendTranslationRequest(textsToTranslate, nodeMapping, baseLanguage, language, previousLanguage);
                }
            } else {
                console.error('Error al buscar traducciones almacenadas:', xhr.responseText);
            }
        };
        xhr.onerror = function () {
            console.error('Error en la solicitud AJAX.');
        };

        // Enviar la solicitud AJAX para verificar si las traducciones ya están almacenadas
        xhr.send('action=gpt_translate_text&page_id=' + encodeURIComponent(currentPageId) + '&language=' + encodeURIComponent(language) + '&previous_language=' + encodeURIComponent(previousLanguage) + '&texts=' + encodeURIComponent(JSON.stringify(textsToTranslate)));
    }

    // Función para enviar la solicitud de traducción al servidor
    function sendTranslationRequest(textsToTranslate, nodeMapping, baseLanguage, targetLanguage, previousLanguage) {
        console.log('Enviando solicitud de traducción a la API...');

        var xhr = new XMLHttpRequest();
        xhr.open('POST', gptTranslationAjax.ajaxurl, true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
        xhr.onload = function () {
            if (xhr.status >= 200 && xhr.status < 400) {
                var response = JSON.parse(xhr.responseText);
                if (response.success) {
                    console.log('Traducciones recibidas y aplicadas.');
                    applyTranslations(response.data, nodeMapping);
                } else {
                    console.error('Error al traducir:', response.data);
                }
            } else {
                console.error('Error de servidor:', xhr.responseText);
            }
        };
        xhr.onerror = function () {
            console.error('Error en la solicitud AJAX.');
        };

        xhr.send('action=gpt_translate_text&page_id=' + encodeURIComponent(currentPageId) + '&language=' + encodeURIComponent(targetLanguage) + '&previous_language=' + encodeURIComponent(previousLanguage) + '&texts=' + encodeURIComponent(JSON.stringify(textsToTranslate)));
    }

    // Función para aplicar las traducciones a los nodos
    function applyTranslations(translations, nodeMapping) {
        for (var i = 0; i < nodeMapping.length; i++) {
            if (translations[i]) {
                nodeMapping[i].nodeValue = translations[i];
            }
        }
        console.log('Traducciones aplicadas con éxito.');
    }
});